package com.example.employee.kotlin_shop_test.UserCenter.presenter.view

import com.example.employee.kotlin_shop_test.BaseLibrary.presenter.view.BaseView

interface ForgetPwdView : BaseView {

    fun onForgetPwdResult(result: String)

}