package com.example.employee.kotlin_shop_test.UserCenter.data.protocol

data class RegisterReq(val mobile: String, val verifyCode: String, val pwd: String) {}