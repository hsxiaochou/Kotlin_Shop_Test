package com.example.employee.kotlin_shop_test.UserCenter.data.protocol

data class LoginReq(val mobile: String, val pwd: String)