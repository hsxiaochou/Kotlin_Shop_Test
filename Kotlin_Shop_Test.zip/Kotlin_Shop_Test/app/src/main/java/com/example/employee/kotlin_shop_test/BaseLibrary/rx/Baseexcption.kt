package com.example.employee.kotlin_shop_test.BaseLibrary.rx

class Baseexcption(val status: Int, val msg: String) : Throwable() {
}