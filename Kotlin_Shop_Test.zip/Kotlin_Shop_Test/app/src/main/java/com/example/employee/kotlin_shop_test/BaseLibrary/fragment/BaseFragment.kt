package com.example.employee.kotlin_shop_test.BaseLibrary.fragment

import androidx.fragment.app.Fragment
import io.reactivex.disposables.CompositeDisposable


//open class BaseFragment : androidx.fragment.app.Fragment() {
//    protected val disposables = CompositeDisposable()
//
//    override fun onDestroy() {
//        super.onDestroy()
//        disposables.dispose()
//    }
//
//}